#pragma once

#include <exception>
#include <iostream>

#include "tjess/transport/node.h"

#ifdef WIN32
#include "Windows.h"
#define EXPORTCALL __declspec(dllexport) __stdcall

// define callback types here for windows
typedef void(__stdcall* OneCharHandler)(const char*);
typedef void(__stdcall* TwoCharHandler)(const char*, const char*);
typedef void(__stdcall* ThreeCharHandler)(const char*, const char*, const char*);
#else
#define EXPORTCALL  // for linux we define it as empty
// callback types
typedef void (*OneCharHandler)(const char*);
typedef char* (*TwoCharHandler)(const char*, const char*);
typedef char* (*ThreeCharHandler)(const char*, const char*, const char*);
#endif

std::map<std::string, std::shared_ptr<tjess::transport::Node>> g_nodes;
std::map<std::string, tjess::transport::Peer> g_peers;

extern "C"
{
    // we can only use standard types for these functions
    int EXPORTCALL createNode(const char* partition, const char* name)
    {
        try
        {
            // just get the instance this will instantiate the singleton
            std::string id = std::string(partition) + "_" + std::string(name);
            if (g_nodes.count(id) == 0)
            {
                g_nodes.insert(std::make_pair(
                    id, std::make_shared<tjess::transport::Node>(std::string(partition), std::string(name))));
                return 0;
            }
            return 1;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL close(const char* id)
    {
        try
        {
            g_nodes.at(std::string(id))->close();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getId(const char* id, const char* out)
    {
        try
        {
            out = g_nodes.at(std::string(id))->getId().c_str();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getPartition(const char* id, const char* out)
    {
        try
        {
            out = g_nodes.at(std::string(id))->getPartition().c_str();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getName(const char* id, const char* out)
    {
        try
        {
            out = g_nodes.at(std::string(id))->getName().c_str();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getPort(const char* id, uint16_t& out)
    {
        try
        {
            out = g_nodes.at(std::string(id))->getPort();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL setPort(const char* id, const uint16_t& value)
    {
        try
        {
            g_nodes.at(std::string(id))->setPort(value);
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getIp(const char* id, const char* out)
    {
        try
        {
            out = g_nodes.at(std::string(id))->getIp().c_str();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL setIp(const char* id, const char* value)
    {
        try
        {
            g_nodes.at(std::string(id))->setIp(std::string(value));
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL getScope(const char* id, uint8_t& out)
    {
        try
        {
            out = static_cast<uint8_t>(g_nodes.at(std::string(id))->getScope());
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL setScope(const char* id, const uint8_t& value)
    {
        try
        {
            g_nodes.at(std::string(id))->setScope(static_cast<tjess::transport::Scope>(value));
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL spinOnce(const char* id)
    {
        try
        {
            g_nodes.at(std::string(id))->spinOnce();
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL remoteFunction(const char* id, const uint8_t& scope, const char* command, TwoCharHandler func)
    {
        try
        {
            g_nodes.at(std::string(id))
                ->remoteFunction(static_cast<tjess::transport::Scope>(scope), std::string(command),
                                 [func](const std::string& request, std::string& reply, const std::string& meta) {
                                     char* out = nullptr;
                                     out = func(request.c_str(), meta.c_str());
                                     if (out != nullptr)
                                     {
                                         reply = std::string(out);  // this should copy the data
                                     }
                                 });
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL responseFunction(const char* id, const uint8_t& scope, const char* command, OneCharHandler func)
    {
        try
        {
            g_nodes.at(std::string(id))
                ->remoteFunction(static_cast<tjess::transport::Scope>(scope), std::string(command),
                                 [func](const std::string& request) { func(request.c_str()); });
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL subscribe(const char* id, const uint8_t& scope, const char* topic, OneCharHandler func)
    {
        try
        {
            g_nodes.at(std::string(id))
                ->subscribe(static_cast<tjess::transport::Scope>(scope), std::string(topic),
                            [func](const std::string& request) { func(request.c_str()); });
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL publish(const char* id, const uint8_t& scope, const char* topic, const char* msg)
    {
        try
        {
            g_nodes.at(std::string(id))
                ->publish(static_cast<tjess::transport::Scope>(scope), std::string(topic), std::string(msg));
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }
    int EXPORTCALL request(const char* id, const uint8_t& scope, const char* peer_id, const char* remote_function_name,
                           const char* request, const char* response_function_name)
    {
        try
        {
            if (response_function_name != nullptr && response_function_name[0] != '\0')
            {
                g_nodes.at(std::string(id))
                    ->request(static_cast<tjess::transport::Scope>(scope), std::string(peer_id),
                              std::string(remote_function_name), std::string(request),
                              std::string(response_function_name));
            }
            else
            {
                g_nodes.at(std::string(id))
                    ->request(static_cast<tjess::transport::Scope>(scope), std::string(peer_id),
                              std::string(remote_function_name), std::string(request));
            }
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    // PEER FUNCTIONS
    int EXPORTCALL createPeer(const char* partition, const char* name, const char* ip, const uint16_t& port)
    {
        try
        {
            std::string id = std::string(partition) + "_" + std::string(name);
            if (g_peers.count(std::string(id)) == 0)
            {
                g_peers.insert(std::make_pair(id, tjess::transport::Peer()));
                g_peers.at(std::string(id)).partition = std::string(partition);
                g_peers.at(std::string(id)).id = std::string(name);
                g_peers.at(std::string(id)).router_endpoints.push_back("tcp://" + std::string(ip) + ":" + std::to_string(port));
                g_peers.at(std::string(id)).publisher_endpoints.push_back("tcp://" + std::string(ip) + ":" + std::to_string(port + 1));
                return 0;
            }
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL addPeer(const char* id, const char* peer_id)
    {
        try
        {
            g_nodes.at(std::string(id))->addPeer(g_peers.at(peer_id));
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }

    int EXPORTCALL removePeer(const char* id, const char* peer_id)
    {
        try
        {
            g_nodes.at(std::string(id))->removePeer(peer_id);
            return 0;
        }
        catch (const std::exception& e)
        {
            std::cout << e.what() << std::endl;
        }
        return 1;
    }
}