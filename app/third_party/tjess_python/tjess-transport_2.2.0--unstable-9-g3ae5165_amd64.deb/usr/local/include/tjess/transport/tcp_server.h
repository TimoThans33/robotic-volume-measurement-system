#pragma once

#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <zmq.hpp>

#include "tjess/transport/context.h"
#include "tjess/transport/enums.h"
#include "tjess/transport/peer.h"
#include "tjess/transport/utils.h"
#include "tjess/transport/version.h"

namespace tjess
{
namespace transport
{
class TcpServer
{
   private:
    const std::string id_;
    std::mutex id_mutex_;

    const std::string name_;
    std::mutex name_mutex_;

    const std::string partition_;
    std::mutex partition_mutex_;

    std::mutex configuration_mutex_;
    std::string configuration_;

    std::mutex ip_mutex_;
    std::string ip_{"0.0.0.0"};

    uint16_t port_{5010};  // default value

    bool can_still_set_socket_opts_{true};

    // set zmq sockets. Only one socket per type is needed
    zmq::socket_t stream_socket_;

    // callback maps
    std::function<void(const std::string&, std::string&, bool&, bool&)> callback_;

    // binds maps
    bool stream_bound_{false};  // ipc only needs to bind on one endpoint

    bool verbose_logging_{false};

    std::vector<zmq::pollitem_t> poll_items_;

    void processStreamMessage_();

   public:
    TcpServer();
    TcpServer(const std::string&, uint16_t);
    ~TcpServer();

    void close();

    uint16_t getPort();
    void setPort(uint16_t);
    std::string getIp();
    void setIp(const std::string&);
    void setVerboseLogging(bool value);

    // two options
    void bind();
    // second one will set ip and port directly before binding
    void bind(const std::string& ip, uint16_t port);

    // some raw functions to easily extend settings functionality
    void setStreamSocketOpts(int zmq_option, int value);

    // spin functions
    void spinOnce();

    void setCallback(std::function<void(const std::string&)> callback);
    void setCallback(std::function<void(const std::string&, std::string&)> callback);
    void setCallback(std::function<void(const std::string&, std::string&, bool&, bool&)> callback);
};

};  // namespace transport
};  // namespace tjess
