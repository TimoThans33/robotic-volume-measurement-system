#pragma once

#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <zmq.hpp>

#include "tjess/transport/context.h"
#include "tjess/transport/enums.h"
#include "tjess/transport/peer.h"
#include "tjess/transport/utils.h"
#include "tjess/transport/version.h"

namespace tjess
{
namespace transport
{
class Node
{
   private:
    const std::string id_;
    std::mutex id_mutex_;

    const std::string name_;
    std::mutex name_mutex_;

    const std::string partition_;
    std::mutex partition_mutex_;

    std::mutex configuration_mutex_;
    std::string configuration_;

    std::mutex ip_mutex_;
    std::string ip_{"0.0.0.0"};

    uint16_t port_{5010};  // default value

    bool can_still_set_socket_opts_{true};

    Scope node_scope_{Scope::HOST};

    // set zmq sockets. Only one socket per type is needed
    zmq::socket_t pub_socket_;
    zmq::socket_t sub_socket_;
    zmq::socket_t request_socket_;  // still router socket, but only used for requests
    zmq::socket_t router_socket_;

    // callback maps
    std::map<std::string, std::function<void(const std::string&, std::string&, const std::string&)>>
        service_callback_map_;
    std::map<std::string, std::function<void(const std::string&)>> subscriber_callback_map_;

    // binds maps
    std::map<std::string, bool> publisher_binds_map_;
    bool publisher_ipc_bound_{false};  // ipc only needs to bind on one endpoint
    std::map<std::string, bool> router_binds_map_;
    bool router_ipc_bound_{false};  // ipc only needs to bind on one endpoint
    // connection maps
    std::map<std::string, bool> request_connections_map_;
    std::map<std::string, bool> subscriber_connections_map_;

    // scope not known
    std::map<std::string, bool> router_connections_map_;

    std::map<std::string, uint64_t> sequence_number_map_;

    // peers
    std::map<std::string, Peer> peers_;

    // send queues
    std::mutex publish_mutex_;
    std::mutex request_mutex_;

    std::vector<zmq::pollitem_t> poll_items_;

    void processSubscriberMessage_();
    void processRouterMessage_();

    void bindRouter_(const tjess::transport::Scope& scope);
    void bindPublisher_(const tjess::transport::Scope& scope);

    void connectSubscriber_(const Scope& scope, const std::string& topic);
    void connectRequester_(const tjess::transport::Scope& scope, const std::string& peer_id);

    std::string getResponseEndpoint_(const tjess::transport::Scope& scope);

   public:
    Node(const std::string&, const std::string&);
    ~Node();

    void close();

    std::string getId();
    std::string getPartition();
    std::string getName();

    uint16_t getPort();
    void setPort(uint16_t);
    std::string getIp();
    void setIp(const std::string&);
    void setScope(const Scope&);
    Scope getScope();

    // some raw functions to easily extend settings functionality
    void setRequestSocketOpts(int zmq_option, int value);
    void setReceiverSocketOpts(int zmq_option, int value);
    void setPublisherSocketOpts(int zmq_option, int value);
    void setSubscriberSocketOpts(int zmq_option, int value);

    // spin functions
    void spinOnce();

    // peers
    void addPeer(Peer);
    void removePeer(const std::string& peer_id);

    void remoteFunction(const Scope& scope, const std::string& command,
                        std::function<void(const std::string&, std::string&, const std::string&)> callback);
    void remoteFunction(const Scope& scope, const std::string& command,
                        std::function<void(const std::string&, std::string&)> callback);
    void remoteFunction(const Scope& scope, const std::string& command,
                        std::function<void(const std::string&)> callback);

    void subscribe(const Scope& scope, const std::string& topic, std::function<void(const std::string&)> callback);
    void publish(const Scope& scope, const std::string& topic, const std::string& message);

    // execution functions
    void request(const Scope& scope, const std::string& peer_id, const std::string& remote_function_name,
                 const std::string& request, const std::string& reponse_function_name);
    void request(const Scope& scope, const std::string& peer_id, const std::string& remote_function_name,
                 const std::string& request);
    void rawRequest(const tjess::transport::Scope& scope, const std::string& peer_id,
                    const std::string& remote_function_name, const std::string& request,
                    const std::string& response_function_name, const uint8_t& message_type);
};

};  // namespace transport
};  // namespace tjess
