#pragma once

#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <zmq.hpp>

#include "tjess/transport/context.h"
#include "tjess/transport/enums.h"
#include "tjess/transport/peer.h"
#include "tjess/transport/utils.h"
#include "tjess/transport/version.h"

namespace tjess
{
namespace transport
{
class TcpClient
{
   private:
    const std::string id_;
    std::mutex id_mutex_;

    const std::string name_;
    std::mutex name_mutex_;

    const std::string partition_;
    std::mutex partition_mutex_;

    std::mutex configuration_mutex_;
    std::string configuration_;

    std::mutex ip_mutex_;
    std::string ip_{"0.0.0.0"};

    uint16_t port_{5010};  // default value

    bool can_still_set_socket_opts_{true};

    // set zmq sockets. Only one socket per type is needed
    zmq::socket_t stream_socket_;

    // peer identity
    std::mutex peer_identity_mutex_;
    std::string peer_identity_;
    bool connected_{false};

    // callback maps
    std::function<void(const std::string&)> callback_;
    std::function<void()> disconnection_callback_;

    // binds maps
    bool stream_bound_{false};  // ipc only needs to bind on one endpoint

    bool verbose_logging_{false};

    std::vector<zmq::pollitem_t> poll_items_;

    void processStreamMessage_();

   public:
    TcpClient();
    TcpClient(const std::string&, uint16_t);
    ~TcpClient();

    void close();

    uint16_t getPort();
    void setPort(uint16_t);
    std::string getIp();
    void setIp(const std::string&);
    void setVerboseLogging(bool value);

    // two options
    void connect();
    // second one will set ip and port directly before binding
    void connect(const std::string& ip, uint16_t port);
    void disconnect();

    // some raw functions to easily extend settings functionality
    void setStreamSocketOpts(int zmq_option, int value);

    void send(const std::string& msg);
    void receive(std::string& msg);

    // spin functions
    void spinOnce();

    void setCallback(std::function<void(const std::string&)> callback);
    void setDisconnectionCallback(std::function<void()> callback);
};

};  // namespace transport
};  // namespace tjess
