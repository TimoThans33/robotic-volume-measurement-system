#pragma once

#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <zmq.hpp>

#include "tjess/transport/context.h"
#include "tjess/transport/enums.h"
#include "tjess/transport/peer.h"
#include "tjess/transport/utils.h"
#include "tjess/transport/version.h"
#include "tjess/utils/httpparser/httprequestparser.h"
#include "tjess/utils/httpparser/request.h"

namespace tjess
{
namespace transport
{
class HttpServer
{
   private:
    const std::string id_;
    std::mutex id_mutex_;

    const std::string name_;
    std::mutex name_mutex_;

    const std::string partition_;
    std::mutex partition_mutex_;

    std::mutex configuration_mutex_;
    std::string configuration_;

    std::mutex ip_mutex_;
    std::string ip_{"0.0.0.0"};

    uint16_t port_{5010};  // default value

    bool can_still_set_socket_opts_{true};

    // set zmq sockets. Only one socket per type is needed
    zmq::socket_t stream_socket_;

    // callback maps
    // this map consist of METHOD, <URL, FUNCTION>
    std::map<std::string, std::map<std::string, std::function<int(const std::string&, std::string&)>>> callbacks_;

    // Max message size of http requests
    int max_msg_size_{10};

    // binds maps
    bool stream_bound_{false};  // ipc only needs to bind on one endpoint

    std::vector<zmq::pollitem_t> poll_items_;

    void processStreamMessage_();

   public:
    HttpServer();
    HttpServer(const std::string&, uint16_t);
    ~HttpServer();

    void close();

    uint16_t getPort();
    void setPort(uint16_t);
    std::string getIp();
    void setIp(const std::string&);

    // Set max message size of http request
    uint8_t getMaxMessageSize();
    void setMaxMessageSize(uint8_t value);

    // two options
    void bind();
    // second one will set ip and port directly before binding
    void bind(const std::string& ip, uint16_t port);

    // some raw functions to easily extend settings functionality
    void setStreamSocketOpts(int zmq_option, int value);

    // spin functions
    void spinOnce();
    void route(const std::string& method, const std::string& url,
               std::function<int(const std::string&, std::string&)> callback);
    void post(const std::string& url, std::function<int(const std::string&, std::string&)> callback);
    void get(const std::string& url, std::function<int(const std::string&, std::string&)> callback);
};

};  // namespace transport
};  // namespace tjess
