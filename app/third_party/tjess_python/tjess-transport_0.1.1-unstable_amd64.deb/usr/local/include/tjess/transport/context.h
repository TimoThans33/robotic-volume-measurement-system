#pragma once

#include <zmq.hpp>

namespace tjess
{
namespace transport
{
class Context
{
   private:
    zmq::context_t context_{1};
    Context();

   public:
    Context(Context const&) = delete;
    void operator=(Context const&) = delete;
    static Context& getInstance();
    static zmq::context_t& getContext();
    static void closeContext();
};

};  // namespace transport
};  // namespace tjess