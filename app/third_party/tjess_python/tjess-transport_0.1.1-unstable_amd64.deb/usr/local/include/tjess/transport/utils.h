#pragma once

#include <wchar.h>

#include <atomic>
#include <codecvt>
#include <locale>
#include <string>
#include <vector>

namespace tjess
{
namespace transport
{
namespace utils
{
std::string getNamespaceFromTopic(std::string topic);
std::string getCorrectedTopic(const std::string& partition, const std::string& ns, const std::string& topic);

std::string getIpcRouterEndpoint(const std::string& partition, const std::string& ns);
std::string getIpcPublisherEndpoint(const std::string& partition, const std::string& ns);
void createIpcRouterEndpoint(const std::string& partition, const std::string& ns);
void createIpcPublisherEndpoint(const std::string& partition, const std::string& ns);
bool ipcRouterEndpointExists(const std::string& partition, const std::string& ns);
bool ipcPublisherEndpointExists(const std::string& partition, const std::string& ns);

extern std::atomic<bool> ok;

void signalHandler(int signum);
void setupSignalHandlers();

void waitForHostIp(const std::string& ip);
std::vector<std::string> determineHostInterfaces();
bool isPrivateIp(const char*);

};  // namespace utils
};  // namespace transport
};  // namespace tjess