#pragma once

namespace tjess
{
namespace transport
{
namespace version
{
extern const int major;
extern const int minor;
extern const int patch;
};  // namespace version
};  // namespace transport
};  // namespace tjess