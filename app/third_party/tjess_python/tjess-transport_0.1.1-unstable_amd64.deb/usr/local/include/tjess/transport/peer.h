#pragma once

#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <vector>

#include "tjess/transport/enums.h"

namespace tjess
{
namespace transport
{
struct Peer
{
    std::string id;
    std::string partition;

    std::vector<std::string> router_endpoints;
    std::vector<std::string> publisher_endpoints;

    Scope scope{Scope::HOST};

    // connection parameters
    Status status{Status::DISCONNECTED};
};

};  // namespace transport
};  // namespace tjess