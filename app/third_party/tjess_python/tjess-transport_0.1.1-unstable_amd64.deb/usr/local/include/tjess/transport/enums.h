#pragma once

namespace tjess
{
namespace transport
{
enum class MessageType : uint8_t
{
    DEFAULT,
    REQUEST_REPLY,
    REQUEST_ONLY,
    RESPONSE
};

enum class Status
{
    DISCONNECTED,
    CONNECTED,
    EVASIVE,
    EXPIRED
};
enum class Scope
{
    PROCESS,
    HOST,
    PARTITION,
    GLOBAL
};

};  // namespace transport
};  // namespace tjess